# Godot4Tilemaps
 
*** LISCENSE ***
* You can only use the assets for non-commercial projects.
* you can modify the assets
* you can not reditribute or resale, even if modified

if you'd like to use the assets for commercial use, you can purchase a liscense for (3.99) here:

	ITCH LINK:
		https://jackie-codes.itch.io/paradise-asset-pack
		


![Alt text](screenshots/game.PNG)
